
public class BitQuack implements QuackBehavior
{
 
    public void quack(){
        
        System.out.println("Bit! Bit!");
        
    }
}

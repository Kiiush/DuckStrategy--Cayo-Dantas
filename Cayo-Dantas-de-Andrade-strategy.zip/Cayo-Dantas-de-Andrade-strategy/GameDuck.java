
public class GameDuck extends Duck
{
    public void display(){
        System.out.println("Game duck");
    }
}
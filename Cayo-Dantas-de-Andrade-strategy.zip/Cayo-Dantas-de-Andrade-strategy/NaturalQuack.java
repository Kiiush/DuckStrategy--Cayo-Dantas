

public class NaturalQuack implements QuackBehavior
{
 
    public void quack(){
        
        System.out.println("quack! quack! quack!");
        
    }
}

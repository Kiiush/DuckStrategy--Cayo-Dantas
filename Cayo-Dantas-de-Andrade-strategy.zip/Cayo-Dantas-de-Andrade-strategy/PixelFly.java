
public class PixelFly implements FlyBehavior
{
    public void fly(){
        System.out.println("Pixel");
    }
}

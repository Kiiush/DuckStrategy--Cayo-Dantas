
/**
 * Escreva a descrição da interface QuackBehavior aqui.
 * 
 * @author (seu nome) 
 * @version (número da versão ou data)
 */

public interface QuackBehavior{
    public void quack();
}

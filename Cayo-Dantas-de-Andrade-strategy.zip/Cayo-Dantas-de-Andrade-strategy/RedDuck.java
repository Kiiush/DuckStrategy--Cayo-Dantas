

public class RedDuck extends Duck
{
    public void display(){
        System.out.println("Red duck");
    }
}
